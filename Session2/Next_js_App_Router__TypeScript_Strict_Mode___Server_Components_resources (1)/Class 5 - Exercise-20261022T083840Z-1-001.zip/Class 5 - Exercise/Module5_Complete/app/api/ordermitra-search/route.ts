import {
  streamText,
  convertToModelMessages,
  stepCountIs,
  toUIMessageStream,
  createUIMessageStreamResponse,
  type UIMessage,
} from "ai";
import { groq } from "@ai-sdk/groq";
import { searchOrders } from "@/lib/tools/search-orders";

export async function POST(req: Request) {
  const { messages }: { messages: UIMessage[] } = await req.json();

  const result = streamText({
    model: groq("openai/gpt-oss-120b"),
    messages: await convertToModelMessages(messages),
    tools: { searchOrders },
    stopWhen: stepCountIs(3),
    system:
      "You are OrderMitra, an assistant for the Orders dashboard. Be concise. " +
      "Use searchOrders whenever the user asks about specific orders.",
  });

  return createUIMessageStreamResponse({
    stream: toUIMessageStream({ stream: result.stream }),
  });
}
