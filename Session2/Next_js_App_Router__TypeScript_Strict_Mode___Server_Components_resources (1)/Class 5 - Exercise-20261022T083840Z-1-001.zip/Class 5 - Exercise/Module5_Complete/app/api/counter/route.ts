export async function GET() {
  const stream = new ReadableStream({
    async start(controller) {
      for (const n of [1, 2, 3, 4, 5]) {
        controller.enqueue(`data: ${n}\n\n`);
        await new Promise((r) => setTimeout(r, 1000));
      }
      controller.close();
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    },
  });
}
