import { generateText, Output } from "ai";
import { groq } from "@ai-sdk/groq";
import { z } from "zod";

export async function POST(req: Request) {
  const { context, question } = await req.json();

  const { output } = await generateText({
    model: groq("openai/gpt-oss-120b"),
    output: Output.object({
      schema: z.object({
        answer: z.string(),
        confidence: z.enum(["high", "medium", "low"]),
        groundedInSource: z.boolean(),
      }),
    }),
    prompt: `Answer the question using only the provided context.

Context: ${context}

Question: ${question}`,
  });

  return Response.json(output);
}
