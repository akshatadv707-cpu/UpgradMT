import {
  streamText,
  convertToModelMessages,
  stepCountIs,
  toUIMessageStream,
  createUIMessageStreamResponse,
  type UIMessage,
} from "ai";
import { groq } from "@ai-sdk/groq";
import { searchOrders } from "@/lib/tools/search-orders";
import { cancelOrder } from "@/lib/tools/cancel-order";

export async function POST(req: Request) {
  const { messages }: { messages: UIMessage[] } = await req.json();

  const result = streamText({
    model: groq("openai/gpt-oss-120b"),
    messages: await convertToModelMessages(messages),
    tools: { searchOrders, cancelOrder },
    stopWhen: stepCountIs(3),
    system:
      "You are OrderMitra, an assistant for the Orders dashboard. Be concise. " +
      "Use searchOrders to look up orders. When the user explicitly asks to " +
      "cancel a specific order, call cancelOrder immediately with its order " +
      "ID — do not ask the user to confirm in chat first. Calling the tool " +
      "only proposes the cancellation; the UI shows its own confirmation " +
      "card and a human must click Confirm before anything actually happens.",
  });

  return createUIMessageStreamResponse({
    stream: toUIMessageStream({ stream: result.stream }),
  });
}
