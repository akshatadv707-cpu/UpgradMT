import { tool } from "ai";
import { z } from "zod";
import { prisma } from "@/lib/prisma";

// No `execute` on purpose: a tool with execute() runs the instant the model calls it. 
// Omitting it makes this a human-in-the-loop tool the AI SDK
// pauses (part.state === "input-available") and waits for the client to
// supply a result via addToolOutput, instead of running automatically.
// The actual mutation happens in app/api/run-cancel-order/route.ts, called
// only after a human clicks Confirm.
export const cancelOrder = tool({
  description:
    "Cancel an order by its ID. Call this as soon as the user asks to " +
    "cancel a specific order — do not ask them to confirm in chat first. " +
    "Calling this tool only proposes the cancellation and shows the user " +
    "a confirmation card; it does not run until they click Confirm.",
  inputSchema: z.object({
    orderId: z.string().describe("The ID of the order to cancel"),
  }),
});

export async function runCancelOrder({ orderId }: { orderId: string }) {
  const order = await prisma.order.update({
    where: { id: orderId },
    data: { status: "cancelled" },
  });
  return { id: order.id, status: order.status };
}
