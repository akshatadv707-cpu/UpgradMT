import { tool } from "ai";
import { z } from "zod";
import { prisma } from "@/lib/prisma";

export const searchOrders = tool({
  description:
    "Search orders by customer name or status. Use this whenever the " +
    "user asks about specific orders.",
  inputSchema: z.object({
    customerName: z
      .string()
      .optional()
      .describe("Full or partial customer name to search for"),
    status: z
      .enum(["pending", "shipped", "delivered", "cancelled"])
      .optional()
      .describe("Filter by order status"),
  }),
  execute: async ({ customerName, status }) => {
    const orders = await prisma.order.findMany({
      where: {
        ...(customerName && {
          customerName: { contains: customerName },
        }),
        ...(status && { status }),
      },
      orderBy: { createdAt: "desc" },
      take: 10,
    });

    return orders.map((o) => ({
      id: o.id,
      customerName: o.customerName,
      item: o.item,
      status: o.status,
    }));
  },
});
