# OrderMitra — Module 5 Live Demo

A complete, runnable Next.js project for demoing all four Module 5 hands-on labs in class, one by one, without needing a Session 4 project as a starting point.

**Built and verified against the actual installed packages** (not just docs) on 2026-08-21 — `npm install`, `npx prisma generate`, `npx tsc --noEmit`, and `npx next build` were all run for real, and every route was smoke-tested against Groq's live API to confirm it's wired correctly (the API calls succeed in forming and sending a request; only a real `GROQ_API_KEY` is missing in this environment).

## One-time setup (do this before class)

```bash
npm install
cp .env.local.example .env.local
# edit .env.local and paste your real key:
# GROQ_API_KEY=your-key-here

npx prisma generate
npx prisma db push      # creates prisma/dev.db (SQLite, zero config)
npx tsx prisma/seed.ts  # seeds demo orders, including Mr. Iyer's diyas

npm run dev
```

Then open **http://localhost:3000** — it's a home page linking to all five demos.

## What's on the home page, in teaching order

| Route | Chapter | Demo |
|---|---|---|
| `/counter-demo` | Ch.1 · SSE | Hand-rolled streaming counter, no AI model |
| `/orders-basic` | Ch.2 · AI SDK | OrderMitra's first streaming chat |
| `/confidence-demo` | Ch.2 · Confidence Indicator | `generateText` + `Output.object` — self-reported confidence |
| `/orders-search` | Ch.3 · Agentic Patterns | `searchOrders` tool, live Prisma data |
| `/orders-full` | Ch.4 · HITL | `cancelOrder` behind a confirmation card, Stop/Retry |

Each is a self-contained page hitting its own API route — nothing shared between chapters, so you can jump straight to any one live without running the others first. `/orders-full` is the final, complete OrderMitra (search + cancel + confirmation + stop/retry all together), matching the deck's wrap-up.

## Try these live, in order

1. **`/counter-demo`** — just load it, watch 1→5 arrive one per second.
2. **`/orders-basic`** — ask "what can you help with?"
3. **`/confidence-demo`** — the sample context/question are pre-filled; hit "Ask OrderMitra."
4. **`/orders-search`** — ask "find pending orders for Mr. Iyer."
5. **`/orders-full`** — ask "cancel Mr. Iyer's diya order," watch the confirmation card, click **Cancel** first to prove nothing happens, ask again and click **Confirm**.

## Model choice

All five routes use **`openai/gpt-oss-120b`** — OpenAI's open-weight model, served on Groq.

Originally this project used `llama-3.3-70b-versatile` (chat/tools) and `moonshotai/kimi-k2-instruct-0905` (structured output), matching what Groq's docs recommended at the time. **Both were retired from Groq's catalog since then** — confirmed live via `GET /openai/v1/models` on 2026-08-21, which returned a completely different model list. `openai/gpt-oss-120b` was verified working end-to-end for all five routes (chat, tool calling, and structured output via `Output.object`) with a real API key on that date.

**If routes start failing with `model_not_found` again**, Groq's catalog has likely changed again — run this to see what's currently available, then swap the model string in the five `route.ts` files:
```bash
curl -s https://api.groq.com/openai/v1/models -H "Authorization: Bearer $GROQ_API_KEY" | jq -r '.data[].id'
```
Remember: `next start` serves a prebuilt `.next` folder, not live source — after changing a model string, run `npx next build` again before `next start` picks it up (`next dev` doesn't have this problem, it recompiles per-request).

Free tier eligible on a single `GROQ_API_KEY` — no separate signup needed per model.

## Version pins that matter (found the hard way)

The AI SDK ecosystem had major breaking changes very recently. This project is built against what `npm install` actually resolves today — **not** older tutorial-style code you may see elsewhere:

- `ai@7.0.73`, `@ai-sdk/react@4.0.76`, `@ai-sdk/groq@4.0.29`
- `useChat` comes from **`@ai-sdk/react`**, not `ai/react`
- Messages use a **`parts`** array (`part.type === "text"`, `part.text`), not `message.content`
- Sending a message uses **`sendMessage({ text })`**, not `handleSubmit`/`input`
- Tool schemas use **`inputSchema`**, not `parameters`
- Loop bounding uses **`stopWhen: stepCountIs(n)`**, not `maxSteps`
- Route handlers return **`createUIMessageStreamResponse({ stream: toUIMessageStream({ stream: result.stream }) })`**, not `toDataStreamResponse()` or `result.toUIMessageStreamResponse()` (the latter existed but is now deprecated too — this project was updated off it once the deprecation surfaced)
- Server messages need **`await convertToModelMessages(messages)`** before `streamText` — it's async in this version
- Tool confirmation uses **`addToolOutput({ tool, toolCallId, output })`** (not `addToolResult`, which still exists but is deprecated)
- Structured output uses **`generateText({ output: Output.object({ schema }) })`**, reading `{ output }` off the result — `generateObject({ schema })` still exists but is deprecated in favor of this

**Prisma is pinned to `6.19.3`**, not latest (`7.x`) — Prisma 7 removed the simple `datasource { url = "file:./dev.db" }` syntax in favor of adapter-based config, which is unnecessary complexity for a demo. If you ever run `npm install` fresh and it grabs Prisma 7, either re-pin to 6.19.3 or follow Prisma's migration guide for the new `prisma.config.ts` + driver adapter setup.

## If something breaks live

- **"Invalid API Key" everywhere** → `.env.local` isn't set, or the dev server needs a restart (env vars are only read on startup).
- **Tool calls behaving oddly on Llama 3.3** (wrong args, weird reasoning) → this is a real, live example of Chapter 3's "hallucinated parameters" failure mode. Worth calling out rather than treating as broken.
- **`cancelOrder` runs without a Confirm click** → shouldn't be possible; `lib/tools/cancel-order.ts` has no `execute()` by design, so the model can only propose it, never run it directly. If this ever happens, something's wrong with the `part.state === "input-available"` check in `orders-full/page.tsx`.
- **Want to reset the demo data** between class sections → `npx tsx prisma/seed.ts` re-seeds (wipes and recreates all orders, undoing any cancellations from a prior run-through).
