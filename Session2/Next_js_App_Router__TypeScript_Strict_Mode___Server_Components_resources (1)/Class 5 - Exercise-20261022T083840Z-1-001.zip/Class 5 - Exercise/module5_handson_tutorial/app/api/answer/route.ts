import { generateText, Output } from "ai";
import { groq } from "@ai-sdk/groq";
import { z } from "zod";

export async function POST(_req: Request) {
  // ─────────── TODO (Chapter 2 · Confidence Indicator) ────────────
  // Delete this placeholder object once implemented.
  // ────────────────────────────────────────────────────────────────

  return Response.json({
    answer: "TODO: implement app/api/answer/route.ts (Chapter 2).",
    confidence: "low",
    groundedInSource: false,
  });
}
