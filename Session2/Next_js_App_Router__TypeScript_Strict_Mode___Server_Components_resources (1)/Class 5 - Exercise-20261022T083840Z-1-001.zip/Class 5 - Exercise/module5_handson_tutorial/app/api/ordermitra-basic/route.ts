import { notImplementedChatResponse } from "@/lib/stub-response";

export async function POST(_req: Request) {
  // ─────────────── TODO (Chapter 2 · Vercel AI SDK) ───────────────
  // Delete the stub import/call below once implemented.
  // ────────────────────────────────────────────────────────────────
  return notImplementedChatResponse(
    "OrderMitra can't talk yet implement app/api/ordermitra-basic/route.ts (Chapter 2)."
  );
}
