import { notImplementedChatResponse } from "@/lib/stub-response";

export async function POST(_req: Request) {
  // ── TODO (Chapter 4 · Human-in-the-Loop UI) ───────────────────────
  // Wire both searchOrders and cancelOrder into a streamText call.
  // Delete the stub import/call below once implemented.
  // ────────────────────────────────────────────────────────────────
  return notImplementedChatResponse(
    "OrderMitra isn't complete yet implement app/api/ordermitra-full/route.ts (Chapter 4)."
  );
}
