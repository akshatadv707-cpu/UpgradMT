# OrderMitra

Build OrderMitra yourself, one chapter at a time. Every API route you need to write is marked with a `TODO`. **The app runs at every stage**, even before you've written anything every unfinished route returns a safe placeholder instead of crashing, so you can always open any page and see something, not a blank screen or an error.

## Setup

```bash
npm install
# paste your real key: GROQ_API_KEY = your-key-here

npx prisma generate
npx prisma db push
npx tsx prisma/seed.ts

npm run dev
```

Open **http://localhost:3000**.

## What you'll build, in order

| Route                | Chapter                   | File(s) to complete                                                    |
| -------------------- | ------------------------- | ---------------------------------------------------------------------- |
| `/counter-demo`    | Ch.1 · SSE               | `app/api/counter/route.ts`                                           |
| `/orders-basic`    | Ch.2 · AI SDK            | `app/api/ordermitra-basic/route.ts`                                  |
| `/confidence-demo` | Ch.2 · Confidence        | `app/api/answer/route.ts`, <br />`app/api/order-summary/route.ts`  |
| `/orders-search`   | Ch.3 · Agentic Patterns  | `lib/tools/search-orders.ts`, `app/api/ordermitra-search/route.ts` |
| `/orders-full`     | Ch.4 · Human-in-the-Loop | `lib/tools/cancel-order.ts`, `app/api/ordermitra-full/route.ts`    |

Open each file the `TODO`, plus anything you need to know before running it. Work through them in order; each chapter builds on the last.

**Already done for you** (not part of the lesson): the chat UI pages (`app/*/page.tsx`), the database setup (`prisma/`, `lib/prisma.ts`), and `app/api/run-cancel-order/route.ts`. Read them if you're curious how the pieces fit together, but you don't need to write them.

## An important note on Chapter 4

`lib/tools/cancel-order.ts` has a `TODO` and a warning worth reading before you prompt: don't give the `cancelOrder` tool an `execute()` function. If it has one, it runs the moment the model calls it the confirmation card in `/orders-full` never actually gets a chance to block it. Leaving `execute()` off is what makes the human-in-the-loop pattern real instead of decorative. The comment in that file explains where the actual cancellation logic goes instead.

## If a page looks stuck on "TODO"

That's not broken it's the expected placeholder response for whichever route you haven't implemented yet. Once you replace a route's TODO with real code, that page's response updates automatically (no restart needed with `npm run dev`).

**One exception:** if you're using `npm run build && npm start` instead of `npm run dev`, you must re-run `npm run build` after every code change `next start` serves a frozen snapshot, not live source.

## Model

Every route uses `groq("openai/gpt-oss-120b")` via `@ai-sdk/groq`. Free API key, no card required: console.groq.com. If a model ever stops working with a `model_not_found` error, Groq's catalog changed list what's currently available with:

```bash
curl -s https://api.groq.com/openai/v1/models -H "Authorization: Bearer $GROQ_API_KEY" | jq -r '.data[].id'
```
