// app/login/page.tsx
import { signIn } from "@/auth";

export default function LoginPage() {
  return (
    <main className="login-shell">
      <div className="login-card">
        <span className="wordmark">
          <span className="wordmark-mark" />
          <span className="wordmark-text">Orders</span>
        </span>

        <h1 className="login-heading">Sign in to continue</h1>
        <p className="login-subtext">Use your Google account to view your orders.</p>

        <form
          action={async () => {
            "use server";
            await signIn("google", { redirectTo: "/orders" });
          }}
        >
          <button type="submit" className="google-button">
            <svg width="18" height="18" viewBox="0 0 18 18" aria-hidden="true">
              <path fill="#4285F4" d="M17.64 9.2c0-.64-.06-1.25-.16-1.84H9v3.48h4.84a4.14 4.14 0 0 1-1.8 2.72v2.26h2.91c1.7-1.57 2.69-3.88 2.69-6.62z" />
              <path fill="#34A853" d="M9 18c2.43 0 4.47-.8 5.96-2.18l-2.91-2.26c-.81.54-1.84.86-3.05.86-2.35 0-4.34-1.58-5.05-3.71H.98v2.33A9 9 0 0 0 9 18z" />
              <path fill="#FBBC05" d="M3.95 10.71A5.4 5.4 0 0 1 3.67 9c0-.59.1-1.17.28-1.71V4.96H.98A9 9 0 0 0 0 9c0 1.45.35 2.83.98 4.04l2.97-2.33z" />
              <path fill="#EA4335" d="M9 3.58c1.32 0 2.51.45 3.44 1.35l2.58-2.58C13.46.89 11.43 0 9 0A9 9 0 0 0 .98 4.96l2.97 2.33C4.66 5.16 6.65 3.58 9 3.58z" />
            </svg>
            Sign in with Google
          </button>
        </form>

        <p className="login-footer">Local demo — no data leaves your machine.</p>
      </div>
    </main>
  );
}
