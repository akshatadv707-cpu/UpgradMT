// Part 3 challenge - TypeScript: interfaces, generics and discriminated unions.

// 1) Interface describing a product's shape (with an optional field).
interface Product {
  id: number;
  name: string;
  price: number;
  discount?: number;
}

// 2) Generic helper: works for an array of ANY type, keeps the type safe.
function pick<T>(items: T[], index: number): T | undefined {
  return items[index];
}

// 3) Discriminated union: each variant shares a `kind` tag.
type Notification =
  | { kind: "email"; to: string; subject: string }
  | { kind: "sms"; to: string; message: string };

// A switch on `kind` lets TypeScript narrow to the right variant.
function summarize(n: Notification): string {
  switch (n.kind) {
    case "email":
      return `Email to ${n.to}: ${n.subject}`;
    case "sms":
      return `SMS to ${n.to}: ${n.message}`;
    default: {
      // Exhaustiveness check: if a new variant is added and left
      // unhandled, TypeScript will flag this line at compile time.
      const _exhaustive: never = n;
      return _exhaustive;
    }
  }
}

// 4) Combine everything.
const products: Product[] = [
  { id: 1, name: "Keyboard", price: 40 },
  { id: 2, name: "Mouse", price: 25, discount: 5 },
  { id: 3, name: "Monitor", price: 200 },
];

const chosen = pick(products, 1);
if (chosen) {
  const finalPrice = chosen.price - (chosen.discount ?? 0);
  console.log(`Picked: ${chosen.name} - $${finalPrice}`);
}

const notifications: Notification[] = [
  { kind: "email", to: "alice@example.com", subject: "Your order shipped" },
  { kind: "sms", to: "+15551234567", message: "Delivery arriving today" },
];

for (const n of notifications) {
  console.log(summarize(n));
}
