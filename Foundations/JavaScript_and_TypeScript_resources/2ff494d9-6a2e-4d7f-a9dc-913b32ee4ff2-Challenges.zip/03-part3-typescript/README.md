# Part 3 Challenge - TypeScript Core

**From the deck:** "Put Part 3 together"

## Task
1. Write an interface `Product` (`id`, `name`, `price`, optional `discount`).
2. Write a generic function `pick<T>(items: T[], index: number): T | undefined`.
3. Define a discriminated union `Notification` (email vs sms) with a switch handler.
4. Combine them: build a small array, pick one, and print a typed summary.

## Concepts practised
Interfaces (with optional fields), generics, discriminated unions, exhaustive `switch` handling with `never`, nullish coalescing (`??`).

## Files
- `challenge.ts` - the TypeScript solution
- `tsconfig.json` - strict compiler settings
- `package.json` - build/run scripts

## Run it
```bash
npm install     # first time only, installs the TypeScript compiler
npm start       # compiles with tsc, then runs the output
```

## Expected output
```
Picked: Mouse - $20
Email to alice@example.com: Your order shipped
SMS to +15551234567: Delivery arriving today
```
