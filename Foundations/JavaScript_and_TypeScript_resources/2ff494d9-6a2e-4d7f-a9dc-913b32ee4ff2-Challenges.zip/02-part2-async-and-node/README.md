# Part 2 Challenge - Async JavaScript & the Node Toolchain

**From the deck:** "Put Part 2 together"

## Task
1. Write `fetchProduct(id)` that returns a Promise resolving to `{ id, name }` after a short delay.
2. Write an async function that fetches products 1, 2 and 3 in parallel with `Promise.all`.
3. Print each product's name; wrap everything in `try`/`catch`.
4. Add an npm script `products` that runs your file, and start it with `npm run products`.

## Concepts practised
Promises, `async`/`await`, error handling with `try`/`catch`, parallel work with `Promise.all`, `package.json` scripts.

## Files
- `products.js` - the async solution
- `package.json` - defines the `products` script

## Run it
```bash
npm run products
# or
node products.js
```

## Expected output
```
Product #1
Product #2
Product #3
```
