// Part 2 challenge - async JavaScript with Promises, async/await and Promise.all.

// Returns a Promise that resolves to a product after a short delay,
// simulating a slow network/database call.
function fetchProduct(id) {
  return new Promise((resolve) => {
    setTimeout(() => resolve({ id, name: `Product #${id}` }), 300);
  });
}

async function main() {
  try {
    // Fetch all three in parallel instead of one-after-another.
    const products = await Promise.all([
      fetchProduct(1),
      fetchProduct(2),
      fetchProduct(3),
    ]);

    for (const product of products) {
      console.log(product.name);
    }
  } catch (err) {
    console.error("Failed to load products:", err);
  }
}

main();
