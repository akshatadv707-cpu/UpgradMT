// Part 1 challenge - a module that exports data for main.js to use.
// `export` makes `people` available to other files.
export const people = [
  { name: "Alice", age: 30 },
  { name: "Bob", age: 25 },
  { name: "Carol", age: 41 },
];
