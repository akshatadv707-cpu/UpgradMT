// Part 1 challenge - bring the module in and use modern JS features.
import { people } from "./people.js";

// Arrow function + destructuring + template literal.
const describe = ({ name, age }) => `${name} is ${age} years old.`;

for (const person of people) {
  console.log(describe(person));
}
