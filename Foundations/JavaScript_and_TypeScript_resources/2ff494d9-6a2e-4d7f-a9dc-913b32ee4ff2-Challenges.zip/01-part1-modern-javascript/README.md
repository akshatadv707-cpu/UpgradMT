# Part 1 Challenge - Modern JavaScript

**From the deck:** "Put Part 1 together"

## Task
1. Make a file `people.js` that exports an array of 3 person objects (`name`, `age`).
2. In `main.js`, import it and use destructuring to read each person's `name` and `age`.
3. Write an arrow function `describe(person)` that returns a template-literal sentence.
4. Print a `describe(...)` line for every person.

## Concepts practised
ES modules (`import`/`export`), array iteration, object destructuring, arrow functions, template literals.

## Files
- `people.js` - the data module
- `main.js` - imports the data and prints a description per person

## Run it
```bash
node main.js
# or
npm start
```

## Expected output
```
Alice is 30 years old.
Bob is 25 years old.
Carol is 41 years old.
```
