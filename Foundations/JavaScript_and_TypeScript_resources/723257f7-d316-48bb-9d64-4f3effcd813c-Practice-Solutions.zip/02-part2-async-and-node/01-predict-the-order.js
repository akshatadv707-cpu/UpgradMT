// Practice: Predict the order
console.log("A");
setTimeout(() => console.log("B"), 1000);
console.log("C");

// Output order: A, C, B
// A and C are synchronous, so they run immediately, in order.
// B is scheduled by the timer and runs later, after the current code finishes.
