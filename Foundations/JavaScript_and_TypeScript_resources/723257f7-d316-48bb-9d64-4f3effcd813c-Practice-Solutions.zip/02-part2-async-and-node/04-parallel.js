// Practice: Speed it up
function fetchUser(id) {
  return new Promise((resolve) => {
    setTimeout(() => resolve({ id, name: `User ${id}` }), 500);
  });
}

async function main() {
  // Sequential - waits for each in turn (~1000ms total)
  const a = await fetchUser(1);
  const b = await fetchUser(2);
  console.log("sequential:", a.name, b.name);

  // Parallel - both run together (~500ms total)
  const [x, y] = await Promise.all([fetchUser(1), fetchUser(2)]);
  console.log("parallel:", x.name, y.name);
}

main();
