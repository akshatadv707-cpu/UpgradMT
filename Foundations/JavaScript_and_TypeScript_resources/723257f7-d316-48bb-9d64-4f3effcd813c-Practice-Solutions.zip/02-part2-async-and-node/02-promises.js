// Practice: Wait for a result
function fetchUser(id) {
  return new Promise((resolve) => {
    setTimeout(() => resolve({ id, name: "Alice" }), 500);
  });
}

fetchUser(2)
  .then((user) => console.log(user.name))
  .catch(() => console.log("Something went wrong"));
