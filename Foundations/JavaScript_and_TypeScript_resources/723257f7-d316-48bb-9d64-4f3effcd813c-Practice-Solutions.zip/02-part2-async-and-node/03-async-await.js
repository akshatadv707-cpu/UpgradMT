// Practice: Rewrite with await
function fetchUser(id) {
  return new Promise((resolve) => {
    setTimeout(() => resolve({ id, name: "Alice" }), 500);
  });
}

async function main() {
  try {
    const user = await fetchUser(2);
    console.log(user.name);
  } catch (err) {
    console.error(err);
  }
}

main();
