# Part 2 — Async & Node (practice solutions)

Reference solutions for every **Practice** slide in Part 2 of `F2-JS-TS-Essentials.pptx`.

| # | Practice slide | Solution | Run |
|---|----------------|----------|-----|
| 1 | Predict the order | `01-predict-the-order.js` | `node 01-predict-the-order.js` |
| 2 | Wait for a result (Promises) | `02-promises.js` | `node 02-promises.js` |
| 3 | Rewrite with await | `03-async-await.js` | `node 03-async-await.js` |
| 4 | Speed it up (parallel) | `04-parallel.js` | `node 04-parallel.js` |
| 5 | Add and run a script (npm) | `package.json` + `main.js` | `npm start` or `npm run 05-npm-script` |

## Quick run (from this folder)

```bash
npm run 01-predict-the-order
npm run 02-promises
npm run 03-async-await
npm run 04-parallel
npm run 05-npm-script
```

Or run any file directly: `node 02-promises.js`

## Practice 5 — npm scripts

The slide asks for a `package.json` with scripts in **this same folder**:

- `package.json` — `"start": "node main.js"` plus a second script (`hello`)
- `main.js` — prints a message when the script runs

```bash
npm start
# Started via an npm script!
```
