// Practice: Add and run a script
console.log("Started via an npm script!");
