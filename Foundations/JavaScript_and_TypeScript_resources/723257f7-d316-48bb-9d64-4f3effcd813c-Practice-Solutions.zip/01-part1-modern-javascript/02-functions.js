// Practice: Write your own function

// Traditional function
function greetClassic(name) {
  return `Hi, ${name}!`;
}
console.log(greetClassic("Alice"));

// Same thing as an arrow function
const greet = (name) => `Hi, ${name}!`;
console.log(greet("Alice"));

// Bonus: triple as an arrow function
const triple = (n) => n * 3;
console.log(triple(4)); // 12
