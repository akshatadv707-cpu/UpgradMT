// Practice: Make a module — main.js
// Import sayHi and call it with your name.

import { sayHi } from "./greetings.js";

console.log(sayHi("Alice"));
