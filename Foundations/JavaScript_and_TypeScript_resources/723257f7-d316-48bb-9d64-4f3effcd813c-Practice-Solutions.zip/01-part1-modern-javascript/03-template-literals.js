// Practice: Build a sentence
const city = "Paris";
const country = "France";
const population = 2140000;

console.log(`I live in ${city}, ${country}.`);
console.log(`I live in ${city}, ${country}. Population: ${population}.`);
