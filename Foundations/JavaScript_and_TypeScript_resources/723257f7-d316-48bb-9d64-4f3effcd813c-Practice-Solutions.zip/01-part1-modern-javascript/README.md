# Part 1 — Modern JavaScript (practice solutions)

Reference solutions for every **Practice** slide in Part 1 of `F2-JS-TS-Essentials.pptx`.

| # | Practice slide | Solution | Run |
|---|----------------|----------|-----|
| 1 | Make some variables | `01-variables.js` | `node 01-variables.js` |
| 2 | Write your own function | `02-functions.js` | `node 02-functions.js` |
| 3 | Build a sentence (template literals) | `03-template-literals.js` | `node 03-template-literals.js` |
| 4 | Unpack it (destructuring) | `04-destructuring.js` | `node 04-destructuring.js` |
| 5 | Use the dots (spread & rest) | `05-spread-rest.js` | `node 05-spread-rest.js` |
| 6 | Make a module | `greetings.js` + `main.js` | `npm run 06-modules` or `node main.js` |

Hello World (Foundations section, before Part 1) lives in `../00-foundations/hello.js`.

## Quick run (from this folder)

```bash
npm run 01-variables
npm run 02-functions
npm run 03-template-literals
npm run 04-destructuring
npm run 05-spread-rest
npm run 06-modules
```

Or run any file directly: `node 04-destructuring.js`

## Practice 6 — modules

The slide asks for two files in **this same folder**:

- `greetings.js` — exports `sayHi(name)`
- `main.js` — imports `sayHi` and prints a greeting

```bash
node main.js
# Hi, Alice!
```
