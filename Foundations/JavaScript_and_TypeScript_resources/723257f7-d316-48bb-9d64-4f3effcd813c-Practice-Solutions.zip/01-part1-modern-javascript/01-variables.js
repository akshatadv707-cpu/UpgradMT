// Practice: Make some variables
const favouriteColour = "teal";

let counter = 0;
counter = 5; // let can be reassigned

console.log(favouriteColour, counter);

// const cannot be reassigned - uncommenting the next line is an error:
// favouriteColour = "red";
