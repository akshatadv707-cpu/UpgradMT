// Practice: Unpack it

// Array - grab the first two by position
const fruits = ["apple", "banana", "cherry"];
const [firstFruit, secondFruit] = fruits;

// Object - grab by name
const movie = { title: "Inception", year: 2010 };
const { title, year } = movie;

console.log(firstFruit, secondFruit, title, year);
