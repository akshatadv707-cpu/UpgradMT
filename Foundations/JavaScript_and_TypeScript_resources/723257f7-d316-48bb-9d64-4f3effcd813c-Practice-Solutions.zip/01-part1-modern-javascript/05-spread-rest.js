// Practice: Use the dots

// Spread - combine two arrays
const a = [1, 2];
const b = [3, 4];
const combined = [...a, ...b];

// Spread - copy an object with one field changed
const base = { name: "Alice", age: 30 };
const updated = { ...base, age: 31 };

// Rest - collect all arguments, then find the biggest
const max = (...nums) => Math.max(...nums);

console.log(combined);        // [1, 2, 3, 4]
console.log(updated);         // { name: 'Alice', age: 31 }
console.log(max(3, 7, 2, 9)); // 9
