// Practice: Make a module — greetings.js
// Export a function sayHi(name) for main.js to import.

export function sayHi(name) {
  return `Hi, ${name}!`;
}
