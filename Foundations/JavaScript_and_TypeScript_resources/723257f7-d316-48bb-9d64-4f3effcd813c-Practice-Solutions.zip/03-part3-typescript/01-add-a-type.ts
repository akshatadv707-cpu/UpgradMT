// Practice: Add a type
function square(n: number): number {
  return n * n;
}

console.log(square(5)); // 25

// This would be a compile-time error - a string is not a number:
// console.log(square("5"));

export {};
