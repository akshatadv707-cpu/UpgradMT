// Practice: Write a generic
function last<T>(items: T[]): T | undefined {
  return items[items.length - 1];
}

console.log(last([1, 2, 3]));       // 3 (T is number)
console.log(last(["a", "b", "c"])); // "c" (T is string)

export {};
