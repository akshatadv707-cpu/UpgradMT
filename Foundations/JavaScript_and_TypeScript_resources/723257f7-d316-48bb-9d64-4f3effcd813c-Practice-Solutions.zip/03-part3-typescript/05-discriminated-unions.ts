// Practice: Model and handle variants
type Payment =
  | { kind: "cash"; amount: number }
  | { kind: "card"; last4: string };

function describe(p: Payment): string {
  switch (p.kind) {
    case "cash":
      return `Paid $${p.amount} in cash`;
    case "card":
      return `Paid by card ending ${p.last4}`;
  }
}

console.log(describe({ kind: "cash", amount: 20 }));
console.log(describe({ kind: "card", last4: "4242" }));

export {};
