# Part 3 — TypeScript (practice solutions)

Reference solutions for every **Practice** slide in Part 3 of `F2-JS-TS-Essentials.pptx`.

| Practice slide | Solution | Run |
|----------------|----------|-----|
| Add a type | `01-add-a-type.ts` | `npm run 01-add-a-type` |
| Type some values | `02-type-values.ts` | `npm run 02-type-values` |
| Design a shape (interfaces) | `03-interfaces.ts` | `npm run 03-interfaces` |
| Write a generic | `04-generics.ts` | `npm run 04-generics` |
| Model and handle variants (unions) | `05-discriminated-unions.ts` | `npm run 05-discriminated-unions` |

## Quick run (from this folder)

```bash
npm install   # first time only
npm start     # compiles and runs every practice file
```

Or run one practice at a time:

```bash
npm run 01-add-a-type
npm run 02-type-values
npm run 03-interfaces
npm run 04-generics
npm run 05-discriminated-unions
```
