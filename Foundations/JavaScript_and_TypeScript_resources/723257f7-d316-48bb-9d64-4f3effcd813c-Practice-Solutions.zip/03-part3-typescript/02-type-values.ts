// Practice: Type some values
const label: string = "F2";
const count: number = 3;
const active: boolean = true;
const scores: number[] = [10, 20, 30];

// This would be an error - a string can't go into a number[]:
// scores.push("oops");

console.log(label, count, active, scores);

export {};
