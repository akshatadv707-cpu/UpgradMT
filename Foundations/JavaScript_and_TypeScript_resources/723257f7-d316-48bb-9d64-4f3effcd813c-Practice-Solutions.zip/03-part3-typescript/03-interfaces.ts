// Practice: Design a shape
interface Book {
  readonly id: number;
  title: string;
  pages: number;
  author: string;
  year?: number; // optional
}

const book: Book = {
  id: 1,
  title: "Deep Work",
  pages: 296,
  author: "Cal Newport",
};

console.log(book);

export {};
