# Foundations (optional practice solution)

Hello World practice appears in `generate-deck.js` but is **not** in the current `F2-JS-TS-Essentials.pptx` deck. Kept here as a quick Node demo.

| Practice slide | Solution | Run |
|----------------|----------|-----|
| Hello, world | `hello.js` | `node hello.js` |

```bash
node hello.js
```
