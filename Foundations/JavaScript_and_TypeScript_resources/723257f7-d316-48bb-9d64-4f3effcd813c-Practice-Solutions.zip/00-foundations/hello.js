// Practice: Hello, world
// console.log prints a message to the screen.
console.log("Hello, my name is Alex");
console.log("My favourite food is pizza");

// Run it with:  node hello.js
