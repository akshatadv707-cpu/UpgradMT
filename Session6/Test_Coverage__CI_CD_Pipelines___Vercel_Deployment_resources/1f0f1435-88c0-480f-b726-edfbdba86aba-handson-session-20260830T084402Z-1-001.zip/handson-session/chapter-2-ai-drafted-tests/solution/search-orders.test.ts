import { searchOrders } from "./search-orders";

test("finds every order for a customer", async () => {
  const results = await searchOrders.execute({ customerName: "Mr. Iyer" });

  expect(results).toHaveLength(2);
  expect(results[0].item).toBe("Brass diya");
});

test("filters by status as well as name", async () => {
  const results = await searchOrders.execute({
    customerName: "Mr. Iyer",
    status: "packed",
  });

  expect(results).toHaveLength(1);
  expect(results[0].id).toBe("OM-1041");
});

// The gap the coverage report found on this file: everyone tests what a
// search returns, nobody tests what it fails to return.
test("returns an empty array when nothing matches", async () => {
  const results = await searchOrders.execute({
    customerName: "Nobody With This Name",
  });

  expect(results).toEqual([]);
  expect(Array.isArray(results)).toBe(true);
});
