// ============================================================================
// INSTRUCTOR FALLBACK — this is the "as drafted by AI" suite.
//
// Use this only if a student's agent produced something that does not
// reproduce the coverage gap. Copy it to:
//     ordermitra/components/ordermitra-panel.test.tsx
// then run `npm test -- --coverage`.
//
// Verified result with this file in place:
//     ordermitra-panel.tsx    69.23% stmts    uncovered lines 78-86
//
// Lines 78-86 are the stop/retry block. Every test below is reasonable.
// Every test below passes. Nothing here is wrong. It is just not everything.
// ============================================================================

import { render, screen } from "@testing-library/react";
import { OrderMitraPanel } from "./ordermitra-panel";

jest.mock("ai/react", () => ({
  useChat: () => ({
    messages: [
      { id: "1", role: "user", content: "find Mr. Iyer's orders" },
      { id: "2", role: "assistant", content: "Found 2 orders for Mr. Iyer." },
    ],
    input: "",
    handleInputChange: jest.fn(),
    handleSubmit: jest.fn(),
    status: "streaming",
    stop: jest.fn(),
    reload: jest.fn(),
    error: undefined,
  }),
}));

test("renders the assistant's reply", () => {
  render(<OrderMitraPanel />);
  expect(screen.getByText("Found 2 orders for Mr. Iyer.")).toBeInTheDocument();
});

test("renders the user's own message", () => {
  render(<OrderMitraPanel />);
  expect(screen.getByText("find Mr. Iyer's orders")).toBeInTheDocument();
});

test("shows the typing indicator while streaming", () => {
  render(<OrderMitraPanel />);
  expect(screen.getByRole("status")).toHaveTextContent("OrderMitra is typing");
});
