import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { OrderMitraPanel } from "./ordermitra-panel";

// jest.mock is hoisted above the imports, so the factory can only reference
// variables whose names start with "mock". That naming rule is not a style
// choice — break it and Jest throws before a single test runs.
const mockStop = jest.fn();
const mockReload = jest.fn();
const mockHandleSubmit = jest.fn();

let mockChatState: Record<string, unknown>;

jest.mock("ai/react", () => ({
  useChat: () => mockChatState,
}));

// A fresh, boring default before every test. Each test overrides only the
// one field it actually cares about.
beforeEach(() => {
  jest.clearAllMocks();
  mockChatState = {
    messages: [],
    input: "",
    handleInputChange: jest.fn(),
    handleSubmit: mockHandleSubmit,
    status: "ready",
    stop: mockStop,
    reload: mockReload,
    error: undefined,
  };
});

// --- The happy path: what an AI drafts on its own ------------------------

test("shows an empty state before anything is asked", () => {
  render(<OrderMitraPanel />);
  expect(screen.getByText("Ask about an order to get started.")).toBeInTheDocument();
});

test("renders the assistant's reply", () => {
  mockChatState.messages = [
    { id: "1", role: "user", content: "find Mr. Iyer's orders" },
    { id: "2", role: "assistant", content: "Found 2 orders for Mr. Iyer." },
  ];

  render(<OrderMitraPanel />);

  expect(screen.getByText("Found 2 orders for Mr. Iyer.")).toBeInTheDocument();
  expect(screen.getByText("High confidence")).toBeInTheDocument();
});

test("shows the typing indicator while streaming", () => {
  mockChatState.status = "streaming";

  render(<OrderMitraPanel />);

  expect(screen.getByRole("status")).toHaveTextContent("OrderMitra is typing");
});

// --- The gap: what the coverage report found -----------------------------

test("stop button halts a streaming reply", async () => {
  mockChatState.status = "streaming";

  render(<OrderMitraPanel />);
  await userEvent.click(screen.getByText("Stop generating"));

  expect(mockStop).toHaveBeenCalled();
});

test("stop button is not offered when nothing is streaming", () => {
  render(<OrderMitraPanel />);
  expect(screen.queryByText("Stop generating")).not.toBeInTheDocument();
});

test("retry button appears and works after an error", async () => {
  mockChatState.error = new Error("model unavailable");

  render(<OrderMitraPanel />);

  expect(screen.getByRole("alert")).toHaveTextContent("model unavailable");
  await userEvent.click(screen.getByText("Retry"));

  expect(mockReload).toHaveBeenCalled();
});

// --- The branch nobody asks for: a hedged reply --------------------------

test("flags a hedged reply as low confidence", () => {
  mockChatState.messages = [
    { id: "1", role: "assistant", content: "I could not find any order by that name." },
  ];

  render(<OrderMitraPanel />);

  expect(screen.getByText("Low confidence")).toBeInTheDocument();
});
