# Chapter 2 — Prompts

---

## Step 1 — Draft the suite

This prompt is deliberately vaguer than the one on the slides. Run it as-is.
Do **not** add hints about error handling — the gap is the point.

```
Write a Jest + React Testing Library test suite for OrderMitraPanel in
components/ordermitra-panel.test.tsx, covering its core chat functionality.
Mock the useChat hook from "ai/react".
```

**Before you run coverage, write down your guess:** what did it miss?
Actually write it. Comparing your guess to the report is the whole exercise.

---

## Step 2 — Audit

No prompt. Run this yourself:

```bash
npm test -- --coverage
```

Read the `Uncovered Line #s` column for `ordermitra-panel.tsx`. Then open the
component and go look at those exact lines. **What do they do?**

---

## Step 3 — Close the gap

Only now, once you know what is missing, is a prompt useful:

```
Add tests to components/ordermitra-panel.test.tsx for the Stop and Retry
buttons in OrderMitraPanel, confirming they call stop() and reload() from
useChat. The mock will need to return a different status and error per test,
so restructure it into a mutable object set in beforeEach().
```

**Note the ordering.** This prompt only exists because you read the coverage
report first. The audit came before the fix — that is the habit.

---

## Step 4 — The second component

```
Write tests for the searchOrders tool in lib/tools/search-orders.ts.
```

Run coverage again. Then ask yourself the same question about *this* file
before you look: what category of case did it skip?
