# Chapter 2 — Can AI Write Our Tests? Generation & the Coverage Audit





---

## Start from Chapter 1's state

You should have `confidence-badge.test.tsx` and `ordermitra-panel.test.tsx`
green. Chapter 2 overwrites the second one.

Save a copy first if you want it:

```bash
cd ordermitra
cp components/ordermitra-panel.test.tsx components/ordermitra-panel.ch1.bak
```

---

## Step 1 — Let the AI draft the suite 

Run the Step 1 prompt from `prompts.md` exactly as written. Do not improve it.

Then **write down your guess** about what it missed, before running anything.
One line is enough. You will check it in a minute.

Read what it produced the way you would read a colleague's pull request. It will
look complete. It will pass. Nothing in it will be wrong.

---

## Step 2 — Run the coverage report 

```bash
npm test -- --coverage
```

Find the row for `components/ordermitra-panel.tsx` and read the
**Uncovered Line #s** column.

Now open `components/ordermitra-panel.tsx` and look at those exact line numbers.

**What is actually there?** Do not skip this. The number tells you where; only
reading the code tells you whether it matters.

Was your guess right?

### What "coverage" means, and does not

Coverage is the percentage of your code that some test *executed*. That is all.

It answers **"did a test touch this line?"** It has never once answered **"is
this line correct?"** A test that runs every line and asserts nothing scores
100%.

So treat the number as a floor to check, not a target to hit.

---

## Step 3 — Write the missing test 

Use the Step 3 prompt from `prompts.md`.

The mock now has to differ per test — streaming for one, an error for another —
so a single fixed `jest.mock` factory no longer works. The prompt asks for a
mutable object reset in `beforeEach()`. That pattern is worth learning; you will
reuse it constantly.

Re-run `npm test -- --coverage` and confirm the number actually went **up**. A
new green test that did not move coverage did not close the gap.

---

## Step 4 — Same loop, different file 

Run the Step 4 prompt on `lib/tools/search-orders.ts`, then coverage again.

Look at what it skipped. It is a different file, a different function, no React
at all — and it is very likely the *same shape* of gap: the code path where the
answer is **nothing**. Empty result, no match, zero rows.

That repetition is the point. The gap is rarely random.

---

## Done when

- [ ] You wrote down a guess before seeing the report
- [ ] You can name what the uncovered lines actually did
- [ ] Coverage on `ordermitra-panel.tsx` went up after your new test
- [ ] `searchOrders` has a test for the "found nothing" case
- [ ] All tests green: `npm test`

Your **global** coverage is still under 80% at this point, and that is expected
— the cancel-order flow has no tests yet. Chapter 3 handles it.

---

## The thing worth remembering

The AI answered the prompt correctly. The prompt was not the whole
specification.

A sharper prompt — one that names error states and cancellation up front —
genuinely narrows the gap. It has never once removed the need to run coverage
and look. Keep both habits.

Reference answers in `solution/`.
