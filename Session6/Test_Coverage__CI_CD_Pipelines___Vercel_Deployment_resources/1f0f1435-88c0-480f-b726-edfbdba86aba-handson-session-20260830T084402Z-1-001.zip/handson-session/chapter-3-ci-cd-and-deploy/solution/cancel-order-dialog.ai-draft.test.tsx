// ============================================================================
// INSTRUCTOR FALLBACK — the "as drafted by AI" suite for Chapter 3, Step 1.
//
// Use if a student's agent produces something that doesn't reproduce the gap.
// Copy to:  ordermitra/components/cancel-order-dialog.test.tsx
//
// Verified result with this file (plus Ch1 + Ch2 solutions) in place:
//     All files                 78.00%    <- still under the 80% gate
//     cancel-order-dialog.tsx  100.00%    <- read that again
//     cancel-order.ts            0.00%    untouched entirely
//
// The dialog reports ONE HUNDRED PERCENT coverage. Every line runs. And the
// only thing this component exists to do -- keep Confirm disabled until the
// user acknowledges the risk -- is never once checked.
//
// This is slide 47's cautionary tale, on the student's own screen, with their
// own code. Do not rush past it.
// ============================================================================

import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { CancelOrderDialog } from "./cancel-order-dialog";

test("shows the order id and customer name", () => {
  render(
    <CancelOrderDialog
      orderId="OM-1041"
      customerName="Mr. Iyer"
      onConfirm={jest.fn()}
      onDismiss={jest.fn()}
    />
  );

  expect(screen.getByText("Cancel order OM-1041?")).toBeInTheDocument();
  expect(screen.getByText(/Mr. Iyer/)).toBeInTheDocument();
});

test("calls onConfirm when the user confirms", async () => {
  const onConfirm = jest.fn();

  render(
    <CancelOrderDialog
      orderId="OM-1041"
      customerName="Mr. Iyer"
      onConfirm={onConfirm}
      onDismiss={jest.fn()}
    />
  );

  await userEvent.click(screen.getByRole("checkbox"));
  await userEvent.click(screen.getByText("Cancel the order"));

  expect(onConfirm).toHaveBeenCalledWith("OM-1041");
});

test("calls onDismiss when the user keeps the order", async () => {
  const onDismiss = jest.fn();

  render(
    <CancelOrderDialog
      orderId="OM-1041"
      customerName="Mr. Iyer"
      onConfirm={jest.fn()}
      onDismiss={onDismiss}
    />
  );

  await userEvent.click(screen.getByText("Keep the order"));

  expect(onDismiss).toHaveBeenCalled();
});
