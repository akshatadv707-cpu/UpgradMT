// Copy over ordermitra/jest.config.js for Chapter 3 Step 3.
//
// The only change from the starter config is coverageThreshold. That block is
// what turns "we should improve our tests sometime" into a number a machine
// enforces. Below the threshold, the command exits non-zero — so CI fails the
// build even when every single test passes.

const nextJest = require("next/jest");

const createJestConfig = nextJest({ dir: "./" });

/** @type {import('jest').Config} */
const customJestConfig = {
  setupFilesAfterEnv: ["<rootDir>/jest.setup.js"],
  testEnvironment: "jest-environment-jsdom",

  collectCoverageFrom: [
    "components/**/*.{ts,tsx}",
    "lib/**/*.{ts,tsx}",
    "!**/*.d.ts",
  ],

  coverageThreshold: {
    global: {
      statements: 80,
      branches: 80,
      functions: 80,
      lines: 80,
    },
  },
};

module.exports = createJestConfig(customJestConfig);
