# Vercel Setup — Reference

Do steps 1–3 **before** class if at all possible. They involve account creation
and email verification, which is the single most common way this hands-on
overruns.

---

## 1. Push the repo to GitHub

Run these from inside `ordermitra/`. The repo root must be the folder holding
`package.json`, or Vercel will not find the app.

```bash
cd ordermitra
git init -b main
git add .
git commit -m "OrderMitra: tested and ready to ship"
gh repo create ordermitra --public --source=. --push
```

Git older than 2.28 rejects `-b main`: use plain `git init`, then
`git branch -M main` after the commit.

No `gh` CLI? Create an empty repo on github.com, then:

```bash
git remote add origin https://github.com/<you>/ordermitra.git
git branch -M main
git push -u origin main
```

**Check `node_modules/` is not in the commit.** The starter `.gitignore` covers
it. `git status` should show nothing about node_modules.

---

## 2. Connect Vercel

1. vercel.com → sign in **with GitHub**
2. Add New → Project
3. Import `ordermitra`
4. Framework preset: Next.js (auto-detected)
5. Root directory: leave as-is if the repo root *is* the app; set to
   `ordermitra` if you pushed the whole hands-on folder
6. Deploy

---

## 3. Environment variable

The tests do not need a key. The **running app** does, if you want the chat to
actually answer.

Vercel → Project → Settings → Environment Variables:

| Name | Value | Environments |
|---|---|---|
| `ANTHROPIC_API_KEY` | your key | Production, Preview, Development |

Redeploy after adding it — env vars are read at build time.

Without the key: the app builds, deploys, and renders fine. Sending a message
returns an error, and the Retry button appears — which is, conveniently, the
exact state you wrote a test for.

---

## 4. Branch protection (the setting that makes CI mean something)

Without this, the green check is a suggestion. Anyone can merge past a red one.

GitHub repo → Settings → Branches → Add branch protection rule:

- Branch name pattern: `main`
- ✅ Require status checks to pass before merging
- Search for and select **`test`** (the job name from `test.yml`)
- Save

The check only appears in that search list **after it has run at least once**.
So push first, let CI run, then come back and add the rule.

Now the Merge button is greyed out until CI is green — including for you.

---

## 5. What a preview deployment gets you

Every pull request gets its own live URL, automatically:

```
ordermitra-git-fix-abort-retry-<you>.vercel.app
```

A reviewer can click through the actual feature before it is merged. This is
where someone would have clicked Stop and Retry three times fast — the thing no
test caught.

---

## 6. Rollback

Vercel keeps every past deployment live.

Project → Deployments → pick a known-good one → ⋯ → **Promote to Production**.

No rebuild, no CI wait. It just repoints the production URL at a build that
already exists. Reverting is seconds, not minutes — worth knowing before you
need it at 11pm.
