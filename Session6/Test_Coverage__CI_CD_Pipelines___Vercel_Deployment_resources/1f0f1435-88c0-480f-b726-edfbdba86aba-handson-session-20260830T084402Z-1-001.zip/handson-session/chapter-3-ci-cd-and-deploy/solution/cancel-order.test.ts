// Chapter 3 — the destructive tool behind the dialog.
// The AI draft tested that cancelling works. These test that it refuses.

import { cancelOrder } from "./cancel-order";

test("cancels an order that has not shipped", async () => {
  const result = await cancelOrder.execute({ orderId: "OM-1041" });

  expect(result.ok).toBe(true);
  if (result.ok) {
    expect(result.order.customerName).toBe("Mr. Iyer");
  }
});

test("refuses to cancel an order that has already shipped", async () => {
  const result = await cancelOrder.execute({ orderId: "OM-1042" });

  expect(result.ok).toBe(false);
  if (!result.ok) {
    expect(result.reason).toMatch(/shipped/);
  }
});

test("refuses to cancel an order that was already delivered", async () => {
  const result = await cancelOrder.execute({ orderId: "OM-1043" });

  expect(result.ok).toBe(false);
});

test("reports a clear reason for an unknown order id", async () => {
  const result = await cancelOrder.execute({ orderId: "OM-9999" });

  expect(result.ok).toBe(false);
  if (!result.ok) {
    expect(result.reason).toMatch(/No order found/);
  }
});
