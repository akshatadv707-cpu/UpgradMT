// Chapter 3 — the completed suite.
// The three tests from the AI draft are kept; the guard tests are what a
// human had to notice were missing.

import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { CancelOrderDialog } from "./cancel-order-dialog";

function renderDialog(overrides: Partial<Parameters<typeof CancelOrderDialog>[0]> = {}) {
  const props = {
    orderId: "OM-1041",
    customerName: "Mr. Iyer",
    onConfirm: jest.fn(),
    onDismiss: jest.fn(),
    ...overrides,
  };
  render(<CancelOrderDialog {...props} />);
  return props;
}

// --- What the AI drafted -------------------------------------------------

test("shows the order id and customer name", () => {
  renderDialog();
  expect(screen.getByText("Cancel order OM-1041?")).toBeInTheDocument();
  expect(screen.getByText(/Mr. Iyer/)).toBeInTheDocument();
});

test("calls onConfirm when the user confirms", async () => {
  const { onConfirm } = renderDialog();

  await userEvent.click(screen.getByRole("checkbox"));
  await userEvent.click(screen.getByText("Cancel the order"));

  expect(onConfirm).toHaveBeenCalledWith("OM-1041");
});

test("calls onDismiss when the user keeps the order", async () => {
  const { onDismiss } = renderDialog();

  await userEvent.click(screen.getByText("Keep the order"));

  expect(onDismiss).toHaveBeenCalled();
});

// --- The guard: what 100% line coverage did not check --------------------

test("confirm button is disabled until the risk is acknowledged", () => {
  renderDialog();
  expect(screen.getByText("Cancel the order")).toBeDisabled();
});

test("does not cancel when confirm is clicked without acknowledgement", async () => {
  const { onConfirm } = renderDialog();

  // Clicking a disabled button must be a no-op, not a cancelled order.
  await userEvent.click(screen.getByText("Cancel the order"));

  expect(onConfirm).not.toHaveBeenCalled();
});

test("dismissing never cancels the order", async () => {
  const { onConfirm } = renderDialog();

  await userEvent.click(screen.getByRole("checkbox"));
  await userEvent.click(screen.getByText("Keep the order"));

  expect(onConfirm).not.toHaveBeenCalled();
});

test("unticking the box disables confirm again", async () => {
  renderDialog();
  const checkbox = screen.getByRole("checkbox");

  await userEvent.click(checkbox);
  expect(screen.getByText("Cancel the order")).toBeEnabled();

  await userEvent.click(checkbox);
  expect(screen.getByText("Cancel the order")).toBeDisabled();
});
