# Chapter 3 — Prompts

Chapter 2 tested the chat panel. This chapter's target is the part of
OrderMitra that can actually destroy something: the **cancel-order flow** —
`components/cancel-order-dialog.tsx` and `lib/tools/cancel-order.ts`.

Neither has a single test yet.

---

## Step 1 — Draft tests for the cancel flow

Open-ended on purpose, one last time.

```
Write a Jest + React Testing Library test suite for CancelOrderDialog in
components/cancel-order-dialog.tsx, and a Jest test suite for the
cancelOrder tool in lib/tools/cancel-order.ts.
```

**Predict the gap first, and write it down.** Third time doing this — your
guess should be sharper than it was in Chapter 2. Check whether it is.

---

## Step 2 — Audit

```bash
npm test -- --coverage
```

Read the report carefully. Then read the component.

The question to ask is not "what line is uncovered?" It is:

> **What is this component for, and did anything test that?**

---

## Step 3 — Close the gap

Once you know what is missing:

```
Add tests to components/cancel-order-dialog.test.tsx proving the
confirmation gate actually holds: the confirm button must be disabled
before the acknowledgement checkbox is ticked, and onConfirm must never
fire while it is disabled.

Then add tests to lib/tools/cancel-order.test.ts for the cases where
cancelOrder refuses: an order that already shipped, one already delivered,
and an unknown order id.
```

Confirm **global** coverage crosses 80% before moving on.

---

## Step 4 — Add the CI workflow

```
Add a GitHub Actions workflow at .github/workflows/test.yml that runs on
every push and pull request: checkout, set up Node 20 with npm caching,
run npm ci, then run npm test with coverage.
```

**Verify before committing:**

- The file is at `.github/workflows/test.yml` — that exact path. GitHub ignores
  workflows anywhere else, silently and with no error.
- It uses `npm ci`, not `npm install`.
- `node-version` matches your local Node (`node -v`).
- No API key is written into the file.

---

## Step 5 — Add the coverage threshold

```
Add a coverageThreshold to jest.config.js requiring 80% global coverage for
statements, branches, functions and lines.
```

Run `npm test -- --coverage` locally before pushing. If it fails here, it fails
in CI.

---

## Step 6 — Make it a git repository (first time only)

The starter arrives as plain files. There is no `.git` folder yet, so
`git add .` will fail with *"fatal: not a git repository"* until you do this.

**Run these from inside `ordermitra/`** — not from the pack root. The repo root
must be the folder containing `package.json`, or Vercel will not find the app.

```bash
cd ordermitra
git init -b main
git add .
git commit -m "Test the cancel-order gate + add CI"
```

Check `git status --short` before committing: you should see about 20 files and
**no `node_modules`**. If `node_modules` appears, you are in the wrong folder or
`.gitignore` is missing.

Older git (below 2.28) rejects `-b main`. Use:

```bash
git init
git add .
git commit -m "Test the cancel-order gate + add CI"
git branch -M main
```

---

## Step 7 — Push it

Create the remote and push. With the GitHub CLI:

```bash
gh repo create ordermitra --public --source=. --push
```

Without it — create an empty repo on github.com (no README, no .gitignore),
then:

```bash
git remote add origin https://github.com/<your-username>/ordermitra.git
git push -u origin main
```

Open the **Actions** tab and watch it run.

Already have a repo from an earlier session? Then skip Step 6 entirely and just
`git add . && git commit -m "..." && git push`.
