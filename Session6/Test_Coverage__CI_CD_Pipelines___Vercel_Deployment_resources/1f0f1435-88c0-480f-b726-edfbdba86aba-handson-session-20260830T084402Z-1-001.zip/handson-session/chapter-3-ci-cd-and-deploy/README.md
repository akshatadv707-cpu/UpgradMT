# Chapter 3 — Shipping It: CI, GitHub Actions & Vercel




---

## Do this before class if you can

Account setup is what eats the clock, not the code:

- [ ] A GitHub account you are logged into
- [ ] A Vercel account, **signed in with GitHub**
- [ ] `git` configured (`git config --global user.name` / `user.email`)

Full walkthrough in `solution/vercel-setup.md`.

---

## This chapter's target

Chapter 2 tested the chat panel. This one tests the part of OrderMitra that can
destroy something a customer cares about:

- `components/cancel-order-dialog.tsx` — the confirmation gate
- `lib/tools/cancel-order.ts` — the destructive tool behind it

Neither has a single test. Run `npm test -- --coverage` right now and look at
your global number. It is below 80%, and these two files are why.

---

## Step 1 — Draft tests for the cancel flow 

Run the Step 1 prompt from `prompts.md`.

**Predict the gap first. Write it down.** Third time — is your guess better than
it was in Chapter 2?

---

## Step 2 — Audit 

```bash
npm test -- --coverage
```

Look at the row for `cancel-order-dialog.tsx`.

There is a good chance it says **100%**.

Now go and read the component. It exists for exactly one reason: the "Cancel the
order" button stays **disabled** until the user ticks the acknowledgement box.
That is the guard. That is the whole point of the file.

**Did any test check it?**

Almost certainly not. The draft ticked the box and clicked confirm, which runs
every line — so the coverage tool reports total success while the only safety
property in the component sits unverified.

This is what people mean when they say coverage is a floor, not a target.
Coverage answers *"did a test touch this line?"* It has never once answered
*"is this code correct?"*

Check `cancel-order.ts` too. The draft almost certainly tested that cancelling
**works**. Did anything test that it **refuses** — an order that already
shipped, or an id that does not exist?

---

## Step 3 — Close the gap 

Use the Step 3 prompt.

Note what you are adding: tests that assert something **does not happen**.
`expect(onConfirm).not.toHaveBeenCalled()`. Those are the tests that protect a
gate, and they are the ones nobody writes unprompted — including you, until
about ninety seconds ago.

Confirm global coverage crosses **80%** before moving on.

---

## Step 4 — Add the CI workflow 

Run the Step 4 prompt, or copy `solution/test.yml` to
`.github/workflows/test.yml`.

### Two details worth understanding, not just copying

**`npm ci`, not `npm install`.** `npm install` may update your lockfile —
convenient locally, wrong in CI. `npm ci` installs the exact locked versions and
fails loudly if the lockfile is out of sync. A CI machine should produce an
identical result every run; that is its entire job.

**No API key in the file.** Every test mocks the model, so CI needs nothing
secret. If a real project does, it goes in repo Settings -> Secrets and is
referenced as `${{ secrets.ANTHROPIC_API_KEY }}`. The workflow file is committed
to the repo — anything hardcoded in it leaks the moment the repo goes public.
Same instinct as `.env.local` from Session 4.

---

## Step 5 — Add the coverage threshold 

Copy `solution/jest.config.with-threshold.js` over `jest.config.js`, or use the
Step 5 prompt.

**Try this, it takes 30 seconds:** temporarily delete your new cancel-flow
tests and run coverage again. Every remaining test passes — and the command
still fails:

```
Jest: "global" coverage threshold for statements (80%) not met: 68%
```

That is the difference between "the tests pass" and "the suite is good enough."
Put them back.

---

## Step 6 — Push and watch it ship 

### First, make it a repository

The starter arrives as plain files — there is no `.git` folder yet. Skip this
and you get `fatal: not a git repository`.

**Run from inside `ordermitra/`**, not the pack root. The repo root must be the
folder holding `package.json`, or Vercel will not find the app.

```bash
cd ordermitra
git init -b main
git add .
git commit -m "Test the cancel-order gate + add CI"
```

Before committing, run `git status --short`: about 20 files, and **no
`node_modules`**. If you see `node_modules`, you are in the wrong folder.

*(Git older than 2.28 rejects `-b main` — use plain `git init`, then
`git branch -M main` after the commit.)*

### Then push it

```bash
gh repo create ordermitra --public --source=. --push
```

No `gh` CLI? Create an empty repo on github.com — no README, no .gitignore —
then:

```bash
git remote add origin https://github.com/<your-username>/ordermitra.git
git push -u origin main
```

Already using a repo from an earlier session? Skip the init and just
`git add . && git commit -m "..." && git push`.

### Then watch

1. Open the **Actions** tab on GitHub. Watch it run live.
2. Green check -> Vercel deploys automatically.
3. Open your live URL.

If you have time, add branch protection (`solution/vercel-setup.md`, section 4).
Without it that green check is only a suggestion — anyone can merge past a red
one. With it, Merge is disabled until CI is green, including for you.

---

## Done when

- [ ] Global coverage above 80%, verified by the report
- [ ] The confirmation gate has a test proving it **blocks**
- [ ] `cancelOrder` has tests for the cases where it refuses
- [ ] `.github/workflows/test.yml` committed at that exact path
- [ ] A green check on your commit in the Actions tab
- [ ] A live Vercel URL
- [ ] You have seen a build fail while every test passed

---

## What you actually built

Push anything tomorrow and this whole path runs again without you thinking about
it: tests run, coverage is checked, deployment happens only if both pass.

That is what "done" means for a real feature. Not "it works today" — but "a
machine will keep proving it works."

One honest limit, worth carrying out of this course: CI catches what you thought
to test for. It has never once caught what nobody thought to write down. A
component at 100% coverage with an untested guard is exactly that failure, and
you found one today. The pipeline is not the skill. Reading the report is.

Reference answers in `solution/`.
