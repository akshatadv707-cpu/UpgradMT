// Chapter 1, Part B — the minimal version.
// One fixed mock, one assertion. Chapter 2 grows this file considerably.

import { render, screen } from "@testing-library/react";
import { OrderMitraPanel } from "./ordermitra-panel";

jest.mock("ai/react", () => ({
  useChat: () => ({
    messages: [
      { id: "1", role: "assistant", content: "Found 1 order." },
    ],
    input: "",
    handleInputChange: jest.fn(),
    handleSubmit: jest.fn(),
    status: "ready",
    stop: jest.fn(),
    reload: jest.fn(),
    error: undefined,
  }),
}));

test("renders the assistant's reply", () => {
  render(<OrderMitraPanel />);

  const reply = screen.getByText("Found 1 order.");
  expect(reply).toBeInTheDocument();
});
