# Chapter 1 — Testing OrderMitra: Jest, RTL & Mocking AI



By the end you will have two green tests, and proof that they can actually turn
red.

---

## Before you start

You should already have run the setup in `../SETUP.md`. Sanity check — from
inside the `ordermitra/` folder:

```bash
npm test
```

You should see one passing suite (`view-toggle.test.tsx`). That file is your
worked example: read it before writing anything. It has the three beats every
test has — **Arrange** (render), **Act** (click), **Assert** (expect).

Leave a second terminal running `npm run test:watch` if you like instant
feedback.

---

## Part A — Test the confidence badge 

`components/confidence-badge.tsx` takes one prop, `level`, and renders a label
and a colour class. Three levels: `high`, `medium`, `low`.

1. Create `components/confidence-badge.test.tsx`.
2. Use the prompt in `prompts.md`, or write it by hand.
3. Confirm you get **three separate** `test()` blocks.
4. Run `npm test`.

**Target:** three green tests.

**What to verify yourself:** the tests should query by visible text
(`screen.getByText("High confidence")`), not by CSS class or `data-testid`. That
is the RTL philosophy — find things the way a user would.

---

## Part B — Mock the chat hook 

`components/ordermitra-panel.tsx` calls `useChat` from the `ai/react` package.
That hook talks to a real language model, which means:

- it needs a network call and an API key
- it returns different wording every single run

Neither is acceptable in a test. So we replace the hook with a stunt double.

1. Create `components/ordermitra-panel.test.tsx`.
2. Use the prompt in `prompts.md`.
3. Run `npm test`.

**Target:** a green test that renders a fixed assistant reply, with zero network
calls.

**Then run it twice in a row.** Identical result both times? That repeatability
is the entire point of mocking.

### The two things that usually go wrong here

- **`jest.mock` placed inside a test or `beforeEach`.** It has to be at the top
  level. Jest hoists it above your imports so the component receives the fake on
  import; declared any later, it silently does not apply.
- **An incomplete mock.** The component destructures `messages`, `input`,
  `handleInputChange`, `handleSubmit`, `status`, `stop`, `reload` and `error`.
  Miss one and you get `undefined is not a function` at render, which reads like
  a component bug but is a mock bug.

---

## Part C — Prove your test can fail 

A green test that *cannot* turn red is not testing anything.

1. Open `components/confidence-badge.tsx`.
2. Change the `high` label from `"High confidence"` to `"Very confident"`.
3. Run `npm test`. **It must fail**, and the message must name the missing text.
4. Undo the change. Confirm green again.

If breaking the component did **not** turn a test red, that test was never
checking what you thought it was.

---

## Done when

- [ ] Three green tests for `ConfidenceBadge`, one per level
- [ ] One green test for `OrderMitraPanel` with `useChat` mocked
- [ ] Same result on two consecutive runs
- [ ] You have watched a test go red on purpose, then back to green

Reference answers are in `solution/` — look after you have tried, not before.
