# Chapter 1 — Prompts

Copy these into Claude Code (or whichever agent you are using) from inside
the `ordermitra/` folder. Read what comes back before you run it.

---

## Part A — the confidence badge

```
Extend components/confidence-badge.test.tsx to test all three levels:
high, medium, and low. Each test should confirm the right text and the
right color class appear. Use Jest and React Testing Library, query by
visible text, and write three separate test() blocks.
```

**Before you run it, check:** are there three separate `test()` blocks, or one
test checking three things? Three separate ones tell you exactly which level
broke. One combined test just tells you "something is wrong."

---

## Part B — mock the chat hook

```
Write a test for OrderMitraPanel in components/ordermitra-panel.test.tsx
that mocks the useChat hook from "ai/react" to return one fixed assistant
message, and confirms that message renders on screen.
The mock should also return: input, handleInputChange, handleSubmit,
status, stop, reload, and error — the component destructures all of them.
```

**Before you run it, check:** is `jest.mock(...)` at the top level of the file,
not inside a `test()` or `beforeEach()`? Jest hoists it above the imports, and a
mock declared too late silently does not apply — the test then talks to the real
hook and fails in a confusing way.

---

## Part C — no prompt

Break the component by hand. This one is deliberately not an AI task; the
whole point is to see the failure yourself.
