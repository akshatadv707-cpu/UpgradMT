# Setup — do this before the session

Takes about five minutes on a decent connection. Doing it in the session costs
everyone twenty.

---

## 1. Requirements

- **Node.js 20 or newer** — check with `node -v`
- **git** — check with `git --version`
- An editor, and Claude Code (or whichever AI agent the course is using)

Node 18 will mostly work but is not what CI runs. Use 20.

---

## 2. Install

```bash
cd ordermitra
npm install
```

## 3. Confirm it works

```bash
npm test
```

Expected:

```
PASS  components/view-toggle.test.tsx
Tests:       1 passed, 1 total
```

One passing test is correct. The rest is what you are about to write.

```bash
npm run dev
```

Open http://localhost:3000 — you should see the OrderMitra panel with an empty
state. The chat will not answer without an API key, which is fine: **no test in
this hands-on needs one.** Every test mocks the model.

---

## 4. Before Chapter 3 only

- A GitHub account, logged in
- A Vercel account — **sign in using the GitHub option**, not email
- git identity configured:

```bash
git config --global user.name "Your Name"
git config --global user.email "you@example.com"
```

The `ordermitra/` folder is **not** a git repository yet — you will run
`git init` inside it during Chapter 3, Step 6. Nothing to do now, but it is why
`git add .` fails if you try it early.

---

## Using your own OrderMitra instead

If your app from Sessions 4–5 is working, use it — the exercises are written to
apply to your own code, and the provided app is the fallback.

Two things to check first:

1. **Which package exports `useChat`?** This starter uses `ai` v4 and
   `import { useChat } from "ai/react"`. If yours is on `ai` v5+, the import is
   `@ai-sdk/react`, and messages carry `parts` rather than a `content` string.
   Mock whichever path your component actually imports — read the import line,
   do not copy the one on the slide.
2. **Is Jest configured at all?** If not, copy `jest.config.js`, `jest.setup.js`
   and the `devDependencies` block from this starter's `package.json`.

If your app fights you for more than five minutes, switch to the provided one
and sort yours out afterwards. The point of the session is the testing habit,
not the setup.

---

## If something is broken

```bash
rm -rf node_modules package-lock.json
npm install
```

Still stuck: use the provided `ordermitra/` folder and flag it to the TA.
